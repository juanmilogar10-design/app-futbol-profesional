import streamlit as st
import pandas as pd
import os

st.set_page_config(page_title="Predicciones de Fútbol", layout="wide")

st.title("📊 Predicciones de Fútbol en Tiempo Real")

# Carpeta actual
base_path = os.path.dirname(__file__)

# Selector de liga
liga = st.selectbox(
    "Selecciona la liga:",
    ["La Liga", "Premier League", "Serie A", "Bundesliga", "Ligue 1"]
)

# Mapear CSV según liga
csv_map = {
    "La Liga": "datos_la_liga.csv",
    "Premier League": "datos_premier.csv",
    "Serie A": "datos_serie_a.csv",
    "Bundesliga": "datos_bundesliga.csv",
    "Ligue 1": "datos_ligue_1.csv"
}

csv_file = os.path.join(base_path, csv_map[liga])

# Cargar y mostrar datos
if os.path.exists(csv_file):
    df = pd.read_csv(csv_file)
    st.subheader(f"Predicciones - {liga}")
    st.dataframe(df)
else:
    st.error("CSV no encontrado. Revisa que esté en la carpeta correcta.")


