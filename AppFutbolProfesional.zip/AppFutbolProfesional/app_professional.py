import streamlit as st
import pandas as pd
import os

st.set_page_config(page_title="App Fútbol Profesional", layout="wide")
st.title("Predicciones de Fútbol Profesional")

# Selección de liga
liga = st.selectbox("Elige la liga:", ["La Liga", "Premier League", "Serie A", "Bundesliga"])

# Asignar CSV según liga
csv_files = {
    "La Liga": "datos_la_liga.csv",
    "Premier League": "datos_premier.csv",
    "Serie A": "datos_serie_a.csv",
    "Bundesliga": "datos_bundesliga.csv"
}

archivo = csv_files.get(liga)

if archivo and os.path.exists(archivo):
    df = pd.read_csv(archivo)
    st.subheader(f"Predicciones: {liga}")
    st.dataframe(df)
else:
    st.warning("Archivo CSV no encontrado. Asegúrate de subir todos los archivos.")

